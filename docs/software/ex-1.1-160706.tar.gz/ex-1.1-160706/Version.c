char	version[] = "Version 1.1, February 1, 1978"
    "  (1BSD)  git "
    "160706 21:24";
